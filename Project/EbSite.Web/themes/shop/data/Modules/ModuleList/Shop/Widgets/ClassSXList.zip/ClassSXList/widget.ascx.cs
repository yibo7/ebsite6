﻿
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web.UI.WebControls;
using EbSite.Base.ExtWidgets.WidgetsManage;
using EbSite.Modules.Shop.ModuleCore.Entity;

namespace EbSite.Modules.Shop.Widgets.ClassSXList
{
    public partial class widget : WidgetBase
    {

        public override void LoadData()
        {
            if (ClassID > 0)
            {
                StringDictionary settings = GetSettings();
                if (settings.ContainsKey("delvalue"))
                {
                    string sType = settings["delvalue"];

                }
                EbSite.Entity.NewsClass md = EbSite.BLL.NewsClass.GetModel(ClassID);
                //  drpGoodsType.SelectedValue = md.Annex8;//默认 选中类型
                if (!string.IsNullOrEmpty(md.Annex8))
                {
                    ModuleCore.Entity.TypeNames model =
                        ModuleCore.BLL.TypeNames.Instance.GetEntity(Convert.ToInt32(md.Annex8));

                    List<ModuleCore.Entity.TypeNameValue> lst =
                        ModuleCore.BLL.TypeNameValue.Instance.GetListArray("typenameid=" + ClassID);
                    if (lst.Count > 0)
                    {
                        rpList.DataSource = lst;
                        rpList.DataBind();
                    }
                }
            }
        }
        protected int ClassID
        {
            get
            {
                if (!string.IsNullOrEmpty(Request["cid"]))
                {
                    return int.Parse(Request["cid"]);
                }
                return -1;
            }
        }

        public override string Name
        {
            get { return "ClassSXList"; }
        }

        public override bool IsEditable
        {
            get { return true; }
        }

        public string SXName(int id)
        {
            ModuleCore.Entity.TypeNameValue md = ModuleCore.BLL.TypeNameValue.Instance.GetEntity(id);
            if (!Equals(md, null))
            {
                return md.ValueName;
            }
            return "";
        }
        public string SXValues(string values)
        {
            string str = "";
            if(!string.IsNullOrEmpty(values))
            {
                string[] arry = values.Split('|');
                foreach (var s in arry)
                {
                    str += ModuleCore.BLL.TypeNameValues.Instance.GetEntity(int.Parse(s)).TValues +" ";
                }
            }
            return str;
        }

    }



}